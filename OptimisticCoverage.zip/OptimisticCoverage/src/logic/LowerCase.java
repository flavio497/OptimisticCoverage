package logic;

public class LowerCase {
	
	
	public String Lower(String s){
		
		String lower;
		lower=s.toLowerCase();
		return lower;
		
		
		
	}

}
