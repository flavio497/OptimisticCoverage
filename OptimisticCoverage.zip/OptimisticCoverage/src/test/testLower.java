package test;
import logic.LowerCase;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class testLower {

	@Test
	void testLower() {
		
		LowerCase low=new LowerCase();
		String result=low.Lower("ABC");
		
		assertEquals("abc",result);
		
		
		
		
		
	}

}
